package com.youtube.project.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.youtube.project.model.Employee;

@Repository
public interface EmployeeRepository extends JpaRepository<Employee,Long>{
	//so we don't have to write the sql queries manually
}
